

import Load_dataset_module
from Load_dataset_module import data
import math
Data = data()
User_preference, movie_genres_and_watchers, users, moviesData = Data.returnData()



class similarity():

    def __init__(self):
        self.User_preference = User_preference
        self.movie_genres_and_watchers = movie_genres_and_watchers


    def users(self,User_preference, user1, user2):
        s = list(set(User_preference[user1]['moviesId']) & set(User_preference[user2]['moviesId']))
        user1_moviesId=[]
        user2_moviesId=[]
        for MovieId in s:
            user1_moviesId.append(User_preference[user1][MovieId]['ratings'])
            user2_moviesId.append(User_preference[user2][MovieId]['ratings'])
        return user1_moviesId,user2_moviesId



    def movies(self,User_preference, movie_genres_and_watchers, movie_id1, movie_id2):
        s1=list(set(movie_genres_and_watchers[movie_id1]['users']) & set(movie_genres_and_watchers[movie_id2]['users']))
        movie1_charachteristicks  = []
        movie2_charachteristicks = []
        movie1_genres=movie_genres_and_watchers[movie_id1]['genres']
        movie2_genres=movie_genres_and_watchers[movie_id2]['genres']
        for userId in s1:
            movie1_charachteristicks.append(User_preference[userId][movie_id1]['ratings'])
            movie2_charachteristicks.append(User_preference[userId][movie_id2]['ratings'])
        movie1_charachteristicks.extend(movie1_genres) #Adding Genre to movies
        movie2_charachteristicks.extend(movie2_genres) #Adding Genre to movies
        return movie1_charachteristicks,movie2_charachteristicks




    #TwoUsers,TwoMovies : feature array/list of two users/movies
    def euclidean_similarity(self,TwoUsers, TwoMovies):
        similarity=0
        for a,b in zip(TwoUsers,TwoMovies):
            similarity += (a-b)*(a-b) # Sum of Squares of (TwoUsers[i] - TwoMovies[i])
        similarity = math.sqrt(similarity)
        return 1/(1+similarity) # Calculate the Similarity

    def cosine_similarity(self,TwoUsers, TwoMovies):
        Total_a = Total_b = Total_ab = 0
        for a,b in zip(TwoUsers,TwoMovies):
            Total_a += a*a # Sum of Squares of elements of list TwoUsers
            Total_b += b*b # Sum of Squares of elements of list TwoMovies
            Total_ab +=  a*b # Sum of (TwoUsers[i] * TwoMovies[i]) 
        num = Total_ab
        deno= math.sqrt(Total_a)*math.sqrt(Total_b) #Calculate the Similarity
        if (deno != 0):
            return num/deno  #Calculate the Similarity
        else:
            return 0

    def pearson_similarity(self,TwoUsers, TwoMovies) : 
        Total_a = Total_b = Total_ab = squareTotal_a = squareTotal_b = 0
        n=len(TwoUsers)
        for a,b in zip(TwoUsers,TwoMovies):         
            Total_a += a # Sum of elements of list TwoUsers 
            Total_b += b # Sum of elements of list TwoMovies
            Total_ab += a*b # Sum of (TwoUsers[i] * TwoMovies[i])         
            squareTotal_a += a*a # Sum of Squares of elements of list TwoUsers
            squareTotal_b += b*b # Sum of Squares of elements of list TwoMovies

        #Calculating correlation coefficient. 
        deno = (math.sqrt((n * squareTotal_a - Total_a * Total_a)* (n * squareTotal_b - Total_b * Total_b)))
        if (deno == 0):
            return 0
        else:
            correlation = (n * Total_ab - Total_a * Total_b)/ deno #Calculate the Similarity
            return correlation   

    def jaccard_similarity(self,TwoUsers, TwoMovies):
        N1 = len(set(TwoUsers) & set(TwoMovies)) # No. of common elements
        N2= len(set(TwoUsers) | set(TwoMovies)) # No. of all distinct elements
        if (N2 == 0):
            return 1
        else:
            return N1/N2 #Calculate the Similarity

    def manhattan_similarity(self,TwoUsers, TwoMovies):
        similarity=0
        for a,b in zip(TwoUsers,TwoMovies):
            similarity += abs(a-b)
        return 1/(1+similarity) #Calculate the Similarity




    #Calculate the similarity score between two users

    def user_similarity(self,User_preference, user1, user2, calculator):

        TwoUsers,TwoMovies = self.users(User_preference, user1, user2)
        if calculator == "euclidean":
            return self.euclidean_similarity(TwoUsers, TwoMovies)
        elif calculator == "cosine":
            return self.cosine_similarity(TwoUsers, TwoMovies)
        elif calculator == "pearson":
            return self.pearson_similarity(TwoUsers, TwoMovies)
        elif calculator == "jaccard":
            return self.jaccard_similarity(TwoUsers, TwoMovies)
        elif calculator == "manhattan":
            return self.manhattan_similarity(TwoUsers, TwoMovies)
        else:
            return "This option is not valid"



    #Calculate the similarity score between two movies

    def movie_similarity(self,User_preference, movie_genres_and_watchers, movie_id1, movie_id2, calculator):

        TwoUsers,TwoMovies = self.movies(User_preference, movie_genres_and_watchers, movie_id1, movie_id2)
        if calculator == "euclidean":
            return self.euclidean_similarity(TwoUsers, TwoMovies)
        elif calculator == "cosine":
            return self.cosine_similarity(TwoUsers, TwoMovies)
        elif calculator == "pearson":
            return self.pearson_similarity(TwoUsers, TwoMovies)
        elif calculator == "jaccard":
            return self.jaccard_similarity(TwoUsers, TwoMovies)
        elif calculator == "manhattan":
            return self.manhattan_similarity(TwoUsers, TwoMovies)
        else:
            return "This option is not valid"




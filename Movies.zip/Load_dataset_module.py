
class data():
    
    def  __init__(self):
        self.User_preference = None
        self.movie_genres_and_watchers = None
        
    def LoadTheData(self):
        users={}
        movie_ratings={}

        with open('u.data') as movie_rates:
            movie_rates=movie_rates.read().splitlines()
            for line in movie_rates:
                number=line.split('\t')
                UserId = number[0]
                MovieId = number[1]
                ratings = int(number[2]) #The ratings should be integers, in order to be possible to calculate them
                if UserId not in users:
                    users[UserId] = []
                users[UserId].append(MovieId)
                if MovieId not in movie_ratings:
                    movie_ratings[MovieId] = {}                
                movie_ratings[MovieId][UserId]={'ratings':ratings}
        moviesData={}
        with open('u.item') as data:
            data=data.read().splitlines()
            for lines in data:
                number=lines.split('|',6)
                MovieId = number[0]
                title = number[1]
                genres = number[6].split('|')  #the program start to read from the 6 coloumn because the genre in fifht columns is unknown
                genres = [int(i) for i in genres]            # The genres should be integers, in order to be possible to calculate them
                moviesData[MovieId]={'title':title,'genres':genres}            
        return users, moviesData, movie_ratings



    # The two following functions build the main features of dictionaries

    def BuildTheUser_preference(self,users, moviesData, movie_ratings):
        User_preference={}
        for UserId in users:
            User_preference[UserId]={}
            for MovieId in users[UserId]:
                User_preference[UserId][MovieId]={'movie_title':moviesData[MovieId]['title'],
                                                  'ratings':movie_ratings[MovieId][UserId]['ratings']}
            User_preference[UserId]['moviesId']=users[UserId] #List of Movies watched by UserId
        return User_preference;

    def BuildTheMovie_Genres_and_Watchers(self,moviesData, movie_ratings):
        movie_genres_and_watchers={}
        for MovieId in moviesData:
            movie_genres_and_watchers[MovieId]={'movie_title':moviesData[MovieId]['title'],
                                                'genres':moviesData[MovieId]['genres'],'users':[]}
            if MovieId in movie_ratings:
                for UserId in movie_ratings[MovieId]:
                    movie_genres_and_watchers[MovieId]['users'].append(UserId) 
        return movie_genres_and_watchers;


    #The final step is to concatenate the correct features - elements into the two dictionaries
    def returnData(self):
        users, moviesData, movie_ratings = self.LoadTheData()
        User_preference=self.BuildTheUser_preference(users, moviesData, movie_ratings)
        movie_genres_and_watchers=self.BuildTheMovie_Genres_and_Watchers(moviesData, movie_ratings)
        return User_preference, movie_genres_and_watchers, users, moviesData



